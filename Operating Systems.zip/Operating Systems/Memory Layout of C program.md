[![Memory Layout of C Programs - GeeksforGeeks](https://media.geeksforgeeks.org/wp-content/uploads/memoryLayoutC.jpg)

## Stack 
Grows into Heap
Contains return values
Memory used in function calls

## Heap
Dynamic
Memory we don't know the size
Always gives one piece of memory, no memory in pieces.
