# Threads - POSIX
ultiple tasks with the application can be implemented by separate threads
- Update display
- Fetch data
- Spell cheking
- Answer a network request
Process creation is heavy-weight while thread creation is light-weight
- Simplify code, icrease efficiency

Proceses have their own data, etc (makes communication between process hard). *Threads* run on the same process, so we dont have to comunicate with other process.

## Types
### User Threads

## Kernel Threads