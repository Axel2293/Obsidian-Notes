
# S1
![[Pasted image 20240117173015.png]]
![[Pasted image 20240117173047.png]]

